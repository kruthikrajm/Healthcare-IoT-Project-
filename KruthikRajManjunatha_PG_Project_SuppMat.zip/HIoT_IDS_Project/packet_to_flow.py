# import pandas as pd
# import numpy as np


# # Read packet CSV
# df = pd.read_csv(
#     "captures/live_simulation.csv"
# )


# # Convert protocol numbers
# protocol_map = {
#     6: "tcp",
#     17: "udp",
#     1: "icmp"
# }

# df["proto"] = df["protocol"].map(protocol_map)


# # Create flow identifier
# flow_columns = [
#     "src_ip",
#     "dst_ip",
#     "src_port",
#     "dst_port",
#     "proto"
# ]


# # Aggregate packets into flows
# flows = df.groupby(flow_columns).agg(
#     duration=("length", lambda x: 0),
#     src_bytes=("length", "sum"),
#     dst_bytes=("length", "sum"),
#     src_pkts=("length", "count"),
#     dst_pkts=("length", "count")
# ).reset_index()



# # Add missing training columns

# missing_columns = {

#     "service": "unknown",
#     "conn_state": "unknown",
#     "missed_bytes": 0,

#     "src_ip_bytes": flows["src_bytes"],
#     "dst_ip_bytes": flows["dst_bytes"],

#     "dns_query": "unknown",
#     "dns_qclass": 0,
#     "dns_qtype": 0,
#     "dns_rcode": 0,

#     "dns_AA": "unknown",
#     "dns_RD": "unknown",
#     "dns_RA": "unknown",
#     "dns_rejected": "unknown",

#     "ssl_version": "unknown",
#     "ssl_cipher": "unknown",
#     "ssl_resumed": "unknown",
#     "ssl_established": "unknown",

#     "http_request_body_len": 0,
#     "http_response_body_len": 0,
#     "http_status_code": 0,

#     "weird_name": "unknown",
#     "weird_addl": "unknown",
#     "weird_notice": "unknown"
# }


# for col, value in missing_columns.items():
#     flows[col] = value



# # Arrange columns similar to training data

# output_columns = [
#     "src_ip",
#     "src_port",
#     "dst_ip",
#     "dst_port",
#     "proto",
#     "service",
#     "duration",
#     "src_bytes",
#     "dst_bytes",
#     "conn_state",
#     "missed_bytes",
#     "src_pkts",
#     "src_ip_bytes",
#     "dst_pkts",
#     "dst_ip_bytes",
#     "dns_query",
#     "dns_qclass",
#     "dns_qtype",
#     "dns_rcode",
#     "dns_AA",
#     "dns_RD",
#     "dns_RA",
#     "dns_rejected",
#     "ssl_version",
#     "ssl_cipher",
#     "ssl_resumed",
#     "ssl_established",
#     "http_request_body_len",
#     "http_response_body_len",
#     "http_status_code",
#     "weird_name",
#     "weird_addl",
#     "weird_notice"
# ]


# flows = flows[output_columns]


# flows.to_csv(
#     "captures/live_simulation_flow.csv",
#     index=False
# )


# print("Flow CSV created")
# print(flows.head())
# print(flows.shape)

import pandas as pd



input_file = "/home/vboxuser/captures/packet_data.csv"

output_file = "/home/vboxuser/captures/hiot_flow.csv"



df = pd.read_csv(input_file)



# Protocol mapping

protocol_map = {

    6:"tcp",
    17:"udp",
    1:"icmp"

}


df["proto"] = df["protocol"].map(protocol_map)



# Create bidirectional flow ID


def flow_identifier(row):


    endpoint1 = (
        row["src_ip"],
        row["src_port"]
    )


    endpoint2 = (
        row["dst_ip"],
        row["dst_port"]
    )


    if endpoint1 <= endpoint2:

        return (
            endpoint1,
            endpoint2,
            row["proto"]
        )

    else:

        return (
            endpoint2,
            endpoint1,
            row["proto"]
        )



df["flow_id"] = df.apply(
    flow_identifier,
    axis=1
)



flows=[]



for flow_id, group in df.groupby("flow_id"):



    first = group.iloc[0]



    src_ip = first["src_ip"]

    dst_ip = first["dst_ip"]

    src_port = first["src_port"]

    dst_port = first["dst_port"]



    src_bytes = 0

    dst_bytes = 0


    src_pkts = 0

    dst_pkts = 0



    for _,pkt in group.iterrows():


        if pkt["src_ip"] == src_ip:


            src_bytes += pkt["length"]

            src_pkts += 1



        else:


            dst_bytes += pkt["length"]

            dst_pkts += 1



    duration = (

        group["time"].max()
        -
        group["time"].min()

    )



    # Service detection


    if src_port == 80 or dst_port == 80:

        service="http"


    elif src_port == 443 or dst_port == 443:

        service="https"


    elif src_port == 53 or dst_port == 53:

        service="dns"


    else:

        service="unknown"



    flows.append({

        "src_ip":src_ip,

        "src_port":src_port,

        "dst_ip":dst_ip,

        "dst_port":dst_port,


        "proto":first["proto"],


        "service":service,


        "duration":duration,


        "src_bytes":src_bytes,

        "dst_bytes":dst_bytes,


        "conn_state":"unknown",


        "missed_bytes":0,


        "src_pkts":src_pkts,


        "src_ip_bytes":src_bytes,


        "dst_pkts":dst_pkts,


        "dst_ip_bytes":dst_bytes

    })




flows=pd.DataFrame(flows)



# Add missing IDS features


extra={


"dns_query":"unknown",

"dns_qclass":0,

"dns_qtype":0,

"dns_rcode":0,


"dns_AA":"unknown",

"dns_RD":"unknown",

"dns_RA":"unknown",

"dns_rejected":"unknown",


"ssl_version":"unknown",

"ssl_cipher":"unknown",

"ssl_resumed":"unknown",

"ssl_established":"unknown",


"http_request_body_len":0,

"http_response_body_len":0,

"http_status_code":0,


"weird_name":"unknown",

"weird_addl":"unknown",

"weird_notice":"unknown"


}



for col,val in extra.items():

    flows[col]=val




columns=[

"src_ip",
"src_port",

"dst_ip",
"dst_port",

"proto",

"service",

"duration",

"src_bytes",

"dst_bytes",

"conn_state",

"missed_bytes",

"src_pkts",

"src_ip_bytes",

"dst_pkts",

"dst_ip_bytes",

"dns_query",

"dns_qclass",

"dns_qtype",

"dns_rcode",

"dns_AA",

"dns_RD",

"dns_RA",

"dns_rejected",

"ssl_version",

"ssl_cipher",

"ssl_resumed",

"ssl_established",

"http_request_body_len",

"http_response_body_len",

"http_status_code",

"weird_name",

"weird_addl",

"weird_notice"

]



flows=flows[columns]



flows.to_csv(
    output_file,
    index=False
)



print("\nFlow CSV generated")

print("Saved:")
print(output_file)


print("\nShape:")
print(flows.shape)


print("\nProtocol distribution:")
print(flows.proto.value_counts())


print("\nService distribution:")
print(flows.service.value_counts())