import pandas as pd
import os


BASE_PATH = "/home/vboxuser/captures/zeek_logs"


datasets = [

    ("normal", "normal_conn.csv"),

    ("scanning", "scanning_conn.csv"),

    ("dos", "dos_conn.csv"),

    ("ddos", "ddos_conn.csv"),

    ("backdoor", "backdoor_conn.csv")

]


all_data = []


for label, filename in datasets:

    file_path = os.path.join(
        BASE_PATH,
        label,
        filename
    )


    print("\nLoading:", file_path)


    df = pd.read_csv(file_path)


    print("Shape:", df.shape)


    # Add attack label

    df["type"] = label


    all_data.append(df)



# Combine all traffic

mininet_df = pd.concat(

    all_data,

    ignore_index=True

)



print("\n==============================")

print("Final Dataset Shape:")

print(mininet_df.shape)



print("\nClass Distribution:")

print(
    mininet_df["type"].value_counts()
)



# Save combined dataset

output = os.path.join(

    BASE_PATH,

    "mininet_zeek_dataset.csv"

)


mininet_df.to_csv(

    output,

    index=False

)


print("\nSaved:")

print(output)