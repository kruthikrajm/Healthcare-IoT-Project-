# #!/usr/bin/env python3

# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.cli import CLI
# from mininet.log import setLogLevel, info
# import time


# def HIoT_Network():

#     info('\n*** Creating HIoT Network ***\n')


#     # Create Mininet without controller
#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None
#     )


#     # Add Open vSwitch
#     info('*** Adding Core Switch ***\n')

#     s1 = net.addSwitch(
#         's1',
#         failMode='standalone'
#     )


#     # -----------------------------
#     # Add HIoT Devices
#     # -----------------------------

#     info('*** Adding Healthcare IoT Devices ***\n')


#     # ECG / Infusion Pump
#     h1 = net.addHost(
#         'h1',
#         ip='10.0.0.1',
#         mac='00:00:00:00:00:01'
#     )


#     # Patient Vital Monitor
#     h2 = net.addHost(
#         'h2',
#         ip='10.0.0.2',
#         mac='00:00:00:00:00:02'
#     )


#     # Hospital Server
#     server = net.addHost(
#         'srv',
#         ip='10.0.0.10',
#         mac='00:00:00:00:00:10'
#     )


#     # Attacker
#     attacker = net.addHost(
#         'attacker',
#         ip='10.0.0.66',
#         mac='00:00:00:00:00:66'
#     )


#     # Links

#     info('*** Creating Links ***\n')

#     net.addLink(h1, s1)
#     net.addLink(h2, s1)
#     net.addLink(server, s1)
#     net.addLink(attacker, s1)



#     # -----------------------------
#     # Start Network
#     # -----------------------------

#     info('*** Starting HIoT Network ***\n')

#     net.start()


#     info('*** Network Started Successfully ***\n')



#     # -----------------------------
#     # Packet Capture
#     # -----------------------------

#     info('*** Starting Packet Capture ***\n')


#     server.cmd(
#         'mkdir -p /home/vboxuser/captures'
#     )


#     server.cmd(
#         'tcpdump -i srv-eth0 '
#         '-w /home/vboxuser/captures/live_simulation.pcap &'
#     )


#     time.sleep(3)



#     # -----------------------------
#     # Normal Healthcare Traffic
#     # -----------------------------

#     info('*** Generating Normal Healthcare Traffic ***\n')


#     # Hospital service

#     server.cmd(
#         'python3 -m http.server 80 &'
#     )


#     time.sleep(2)


#     # ECG device sending readings

#     h1.cmd(
#         'for i in $(seq 1 50); do '
#         'curl -s http://10.0.0.10/pump_metric=98; '
#         'sleep 1; '
#         'done &'
#     )


#     # Patient monitor sending readings

#     h2.cmd(
#         'for i in $(seq 1 50); do '
#         'curl -s http://10.0.0.10/pulse_rate=72; '
#         'sleep 1; '
#         'done &'
#     )


#     time.sleep(10)



#     # -----------------------------
#     # Attack Traffic
#     # -----------------------------

#     info('*** Simulating Attack Traffic ***\n')


#     # Controlled ICMP attack

#     attacker.cmd(
#         'ping -c 50 -i 0.1 10.0.0.10'
#     )


#     time.sleep(5)



#     # -----------------------------
#     # Stop Capture
#     # -----------------------------

#     info('*** Stopping Capture ***\n')


#     server.cmd(
#         'killall tcpdump'
#     )


#     h1.cmd(
#         'killall curl'
#     )


#     h2.cmd(
#         'killall curl'
#     )


#     info('*** PCAP Generation Completed ***\n')


#     # Open Mininet CLI

#     CLI(net)


#     net.stop()



# if __name__ == '__main__':

#     setLogLevel('info')

#     HIoT_Network()


#-------------------------------------------------------------------------------------------------------
# #!/usr/bin/env python3

# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.cli import CLI
# from mininet.log import setLogLevel, info
# import time


# def HIoT_Network():

#     info("\n*** Creating HIoT Network ***\n")

#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None
#     )


#     # Switch

#     s1 = net.addSwitch(
#         's1',
#         failMode='standalone'
#     )


#     # Healthcare IoT devices

#     ecg = net.addHost(
#         'ecg',
#         ip='10.0.0.1'
#     )

#     monitor = net.addHost(
#         'monitor',
#         ip='10.0.0.2'
#     )

#     pump = net.addHost(
#         'pump',
#         ip='10.0.0.3'
#     )

#     server = net.addHost(
#         'server',
#         ip='10.0.0.10'
#     )


#     attacker = net.addHost(
#         'attacker',
#         ip='10.0.0.66'
#     )


#     for h in [
#         ecg,
#         monitor,
#         pump,
#         server,
#         attacker
#     ]:
#         net.addLink(h,s1)



#     net.start()


#     info("*** Starting Capture ***\n")


#     server.cmd(
#         "mkdir -p /home/vboxuser/captures"
#     )


#     server.cmd(
#         "tcpdump "
#         "-i server-eth0 "
#         "-w /home/vboxuser/captures/hiot.pcap &"
#     )


#     time.sleep(3)



#     # ----------------------------
#     # Hospital Services
#     # ----------------------------


#     server.cmd(
#         "python3 -m http.server 80 &"
#     )


#     time.sleep(2)



#     # ----------------------------
#     # Normal IoT Traffic
#     # ----------------------------


#     info("*** Normal Medical Traffic ***\n")


#     # ECG readings

#     ecg.cmd(
#         """
#         for i in $(seq 1 100)
#         do
#         curl -X POST \
#         -d "heart_rate=80&spo2=98" \
#         http://10.0.0.10
#         sleep 1
#         done
#         """
#     )



#     # Patient monitor

#     monitor.cmd(
#         """
#         for i in $(seq 1 100)
#         do
#         curl -X POST \
#         -d "temperature=36.5&pulse=72" \
#         http://10.0.0.10
#         sleep 1
#         done
#         """
#     )



#     # Infusion pump large data

#     pump.cmd(
#         """
#         dd if=/dev/urandom \
#         of=/tmp/pump_data.bin \
#         bs=1024 count=200

#         curl \
#         --data-binary @/tmp/pump_data.bin \
#         http://10.0.0.10
#         """
#     )



#     time.sleep(20)



#     # ----------------------------
#     # Attack Traffic
#     # ----------------------------


#     info("*** Attack Traffic ***\n")


#     # Port scanning

#     attacker.cmd(
#         "nmap -sS 10.0.0.10"
#     )


#     time.sleep(3)



#     # ICMP flood

#     attacker.cmd(
#         "ping "
#         "-c 100 "
#         "-i 0.05 "
#         "10.0.0.10"
#     )



#     time.sleep(5)



#     # HTTP flood

#     attacker.cmd(
#         """
#         for i in $(seq 1 300)
#         do
#         curl http://10.0.0.10
#         done
#         """
#     )



#     time.sleep(10)



#     # Stop capture

#     server.cmd(
#         "killall tcpdump"
#     )


#     info(
#         "\n*** PCAP Generated ***\n"
#     )


#     CLI(net)

#     net.stop()



# if __name__=="__main__":

#     setLogLevel('info')

#     HIoT_Network()

#------------------------------------------------------------------------------------------------

#!/usr/bin/env python3

# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.cli import CLI
# from mininet.log import setLogLevel, info
# import time


# def HIoT_Network():

#     info("\n*** Creating HIoT Network ***\n")


#     # ==========================
#     # CREATE NETWORK
#     # ==========================

#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None
#     )


#     s1 = net.addSwitch(
#         's1',
#         failMode='standalone'
#     )


#     # ==========================
#     # HIoT DEVICES
#     # ==========================


#     ecg = net.addHost(
#         'ecg',
#         ip='10.0.0.1',
#         mac='00:00:00:00:00:01'
#     )


#     monitor = net.addHost(
#         'monitor',
#         ip='10.0.0.2',
#         mac='00:00:00:00:00:02'
#     )


#     pump = net.addHost(
#         'pump',
#         ip='10.0.0.3',
#         mac='00:00:00:00:00:03'
#     )


#     server = net.addHost(
#         'server',
#         ip='10.0.0.10',
#         mac='00:00:00:00:00:10'
#     )


#     attacker = net.addHost(
#         'attacker',
#         ip='10.0.0.66',
#         mac='00:00:00:00:00:66'
#     )


#     hosts = [
#         ecg,
#         monitor,
#         pump,
#         server,
#         attacker
#     ]


#     for h in hosts:
#         net.addLink(
#             h,
#             s1
#         )


#     # ==========================
#     # START NETWORK
#     # ==========================

#     net.start()

#     info("\n*** Network Started ***\n")



#     # ==========================
#     # START PACKET CAPTURE
#     # ==========================


#     server.cmd(
#         "mkdir -p /home/vboxuser/captures"
#     )


#     server.cmd(
#         """
#         tcpdump -i server-eth0 \
#         -w /home/vboxuser/captures/hiot.pcap &
#         """
#     )


#     time.sleep(3)



#     # ==========================
#     # SERVER SERVICES
#     # ==========================


#     info("\n*** Starting Hospital Server ***\n")


#     # HTTP service

#     server.cmd(
#         """
#         python3 -m http.server 80 &
#         """
#     )


#     # Dummy TCP services
#     # for attack traffic

#     server.cmd(
#         """
#         nc -lk 4444 &
#         """
#     )


#     server.cmd(
#         """
#         nc -lk 8080 &
#         """
#     )


#     time.sleep(3)



#     # ==========================
#     # NORMAL HEALTHCARE TRAFFIC
#     # ==========================


#     info("\n*** Normal HIoT Traffic ***\n")



#     # ECG device


#     ecg.cmd(
#         """
#         for i in $(seq 1 50)
#         do

#         curl -s \
#         -X POST \
#         -d "heart_rate=80&spo2=98" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )



#     # Patient monitor


#     monitor.cmd(
#         """
#         for i in $(seq 1 50)
#         do

#         curl -s \
#         -X POST \
#         -d "temperature=36.5&pulse=72" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )



#     # Infusion pump


#     pump.cmd(
#         """
#         for i in $(seq 1 30)
#         do

#         curl -s \
#         -X POST \
#         -d "infusion_rate=5&volume=100" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )



#     time.sleep(20)



#     # ==========================
#     # ATTACK TRAFFIC
#     # ==========================


#     info("\n*** Port Scan Attack ***\n")


#     attacker.cmd(
#         """
#         nmap -sS -p 1-100 10.0.0.10
#         """
#     )


#     time.sleep(5)



#     info("\n*** TCP Connection Attack ***\n")


#     attacker.cmd(
#         """
#         for port in 4444 8080 80
#         do

#             for i in $(seq 1 100)
#             do

#                 nc -z 10.0.0.10 $port &

#             done

#         done
#         """
#     )


#     time.sleep(5)



#     info("\n*** HTTP Flood Attack ***\n")


#     attacker.cmd(
#         """
#         for i in $(seq 1 200)
#         do

#             curl -s http://10.0.0.10 &

#         done
#         """
#     )


#     time.sleep(10)



#     info("\n*** ICMP Attack ***\n")


#     attacker.cmd(
#         """
#         ping -c 100 -i 0.05 10.0.0.10 &
#         """
#     )


#     time.sleep(15)



#     # ==========================
#     # STOP CAPTURE
#     # ==========================


#     info("\n*** Stopping Capture ***\n")


#     server.cmd(
#         "killall tcpdump"
#     )


#     info(
#         """
#         =========================
#         PCAP GENERATED
#         Location:
#         /home/vboxuser/captures/hiot.pcap
#         =========================
#         """
#     )


#     CLI(net)


#     net.stop()



# if __name__ == "__main__":

#     setLogLevel('info')

#     HIoT_Network()

#----------------------------------------------------
# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.cli import CLI
# from mininet.log import setLogLevel, info
# import time


# def HIoT_Network():

#     info("\n*** Creating HIoT Network ***\n")


#     # ==========================
#     # CREATE NETWORK
#     # ==========================

#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None
#     )


#     s1 = net.addSwitch(
#         's1',
#         failMode='standalone'
#     )


#     # ==========================
#     # HIoT DEVICES
#     # ==========================

#     ecg = net.addHost(
#         'ecg',
#         ip='10.0.0.1'
#     )


#     monitor = net.addHost(
#         'monitor',
#         ip='10.0.0.2'
#     )


#     pump = net.addHost(
#         'pump',
#         ip='10.0.0.3'
#     )


#     server = net.addHost(
#         'server',
#         ip='10.0.0.10'
#     )


#     attacker = net.addHost(
#         'attacker',
#         ip='10.0.0.66'
#     )


#     hosts=[
#         ecg,
#         monitor,
#         pump,
#         server,
#         attacker
#     ]


#     for h in hosts:
#         net.addLink(
#             h,
#             s1
#         )


#     # ==========================
#     # START NETWORK
#     # ==========================

#     net.start()


#     info("\n*** Network Started ***\n")


#     time.sleep(3)



#     # ==========================
#     # PACKET CAPTURE
#     # ==========================


#     info("\n*** Starting Packet Capture ***\n")


#     server.cmd(
#         "mkdir -p /home/vboxuser/captures"
#     )


#     # Capture entire switch traffic

#     s1.cmd(
#         """
#         tcpdump -i any \
#         -w /home/vboxuser/captures/hiot.pcap &
#         """
#     )


#     time.sleep(3)



#     # ==========================
#     # SERVER SERVICES
#     # ==========================


#     info("\n*** Starting Services ***\n")


#     # HTTP healthcare server

#     server.cmd(
#         """
#         python3 -m http.server 80 &
#         """
#     )


#     # Backdoor simulation

#     server.cmd(
#         """
#         nc -lk 4444 &
#         """
#     )


#     server.cmd(
#         """
#         nc -lk 8080 &
#         """
#     )


#     time.sleep(3)



#     # ==========================
#     # NORMAL HIoT TRAFFIC
#     # ==========================


#     info("\n*** Normal Healthcare Traffic ***\n")


#     # ECG device

#     ecg.cmd(
#         """
#         for i in $(seq 1 100)
#         do

#         curl -s \
#         -X POST \
#         -d "heart_rate=80&spo2=98" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )



#     # Patient monitor


#     monitor.cmd(
#         """
#         for i in $(seq 1 100)
#         do

#         curl -s \
#         -X POST \
#         -d "temperature=36.5&pulse=72" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )



#     # Infusion pump


#     pump.cmd(
#         """
#         for i in $(seq 1 100)
#         do

#         curl -s \
#         -X POST \
#         -d "infusion_rate=5&volume=100" \
#         http://10.0.0.10

#         sleep 1

#         done &
#         """
#     )


#     time.sleep(20)



#     # ==========================
#     # SCANNING ATTACK
#     # ==========================


#     info("\n*** Scanning Attack ***\n")


#     attacker.cmd(
#         """
#         nmap -sS -p 1-1000 10.0.0.10
#         """
#     )


#     time.sleep(10)



#     # ==========================
#     # DOS ATTACK
#     # ==========================


#     info("\n*** HTTP DoS Attack ***\n")


#     attacker.cmd(
#         """
#         for i in $(seq 1 300)
#         do

#         curl -s http://10.0.0.10 &

#         done
#         """
#     )


#     time.sleep(15)



#     # ==========================
#     # BACKDOOR ATTACK
#     # ==========================


#     info("\n*** Backdoor Traffic ***\n")


#     attacker.cmd(
#         """
#         for i in $(seq 1 100)
#         do

#         nc 10.0.0.10 4444 < /etc/passwd

#         done
#         """
#     )


#     time.sleep(10)



#     # ==========================
#     # STOP CAPTURE
#     # ==========================


#     info("\n*** Stopping Capture ***\n")


#     s1.cmd(
#         "killall tcpdump"
#     )


#     info(
#     """
#     ============================
#     PCAP GENERATED

#     /home/vboxuser/captures/hiot.pcap

#     ============================
#     """
#     )


#     CLI(net)


#     net.stop()



# if __name__=="__main__":

#     setLogLevel('info')

#     HIoT_Network()
#-----------------------------------------------

# #!/usr/bin/python3

# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.cli import CLI
# from mininet.log import setLogLevel, info

# import time


# CAPTURE_PATH = "/home/vboxuser/captures"



# def start_capture(switch, filename):

#     switch.cmd(
#         f"""
#         tcpdump -i any \
#         -w {CAPTURE_PATH}/{filename} &
#         """
#     )



# def stop_capture():

#     s1.cmd(
#         "killall tcpdump"
#     )



# def HIoT_Network():


#     info("\n*** Creating HIoT Network ***\n")


#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None
#     )


#     global s1

#     s1 = net.addSwitch(
#         's1',
#         failMode='standalone'
#     )


#     # ==============================
#     # HIoT DEVICES
#     # ==============================


#     ecg = net.addHost(
#         'ecg',
#         ip='10.0.0.1'
#     )


#     monitor = net.addHost(
#         'monitor',
#         ip='10.0.0.2'
#     )


#     pump = net.addHost(
#         'pump',
#         ip='10.0.0.3'
#     )


#     wearable = net.addHost(
#         'wearable',
#         ip='10.0.0.4'
#     )


#     server = net.addHost(
#         'server',
#         ip='10.0.0.10'
#     )


#     attacker = net.addHost(
#         'attacker',
#         ip='10.0.0.66'
#     )


#     hosts=[

#         ecg,
#         monitor,
#         pump,
#         wearable,
#         server,
#         attacker

#     ]


#     for h in hosts:

#         net.addLink(
#             h,
#             s1
#         )



#     net.start()


#     info("\n*** Network Started ***\n")



#     server.cmd(
#         f"mkdir -p {CAPTURE_PATH}"
#     )


#     time.sleep(3)



#     # ==============================
#     # SERVER SERVICES
#     # ==============================


#     server.cmd(
#         "python3 -m http.server 80 &"
#     )


#     server.cmd(
#         "nc -lk 4444 &"
#     )


#     time.sleep(5)



#     # ===================================================
#     # 1. NORMAL HIoT TRAFFIC
#     # ===================================================


#     info("\n*** Capturing NORMAL traffic ***\n")


#     start_capture(
#         s1,
#         "normal.pcap"
#     )


#     ecg.cmd(
#     """

#     for i in $(seq 1 300)

#     do

#     curl -s \
#     -X POST \
#     -d "device=ECG&heartrate=80&spo2=98" \
#     http://10.0.0.10


#     sleep 1

#     done &

#     """
#     )


#     monitor.cmd(
#     """

#     for i in $(seq 1 300)

#     do


#     curl -s \
#     -X POST \
#     -d "temperature=36.5&bp=120/80" \
#     http://10.0.0.10


#     sleep 2


#     done &

#     """
#     )



#     pump.cmd(
#     """

#     for i in $(seq 1 300)

#     do


#     curl -s \
#     -X POST \
#     -d "infusion=5ml" \
#     http://10.0.0.10


#     sleep 3


#     done &

#     """
#     )



#     time.sleep(60)


#     stop_capture()



#     # ===================================================
#     # 2. SCANNING
#     # ===================================================


#     info("\n*** Capturing SCANNING attack ***\n")


#     start_capture(
#         s1,
#         "scanning.pcap"
#     )


#     attacker.cmd(

#     """

#     nmap -sS -p 1-2000 10.0.0.10

#     """

#     )


#     time.sleep(30)


#     stop_capture()



#     # ===================================================
#     # 3. DOS ATTACK
#     # ===================================================


#     info("\n*** Capturing DOS attack ***\n")


#     start_capture(
#         s1,
#         "dos.pcap"
#     )



#     attacker.cmd(

#     """

#     for i in $(seq 1 1000)

#     do

#     curl -s http://10.0.0.10 &


#     done

#     """

#     )


#     time.sleep(30)


#     stop_capture()



#     # ===================================================
#     # 4. BACKDOOR
#     # ===================================================


#     info("\n*** Capturing BACKDOOR traffic ***\n")


#     start_capture(
#         s1,
#         "backdoor.pcap"
#     )


#     attacker.cmd(

#     """

#     for i in $(seq 1 500)

#     do


#     echo "unauthorized access" | nc 10.0.0.10 4444


#     done


#     """

#     )


#     time.sleep(30)


#     stop_capture()



#     info(

#     """

#     ======================================

#     PCAP FILES CREATED:

#     normal.pcap
#     scanning.pcap
#     dos.pcap
#     backdoor.pcap


#     Location:

#     /home/vboxuser/captures/


#     ======================================

#     """

#     )



#     CLI(net)


#     net.stop()





# if __name__ == '__main__':

#     setLogLevel('info')

#     HIoT_Network()

#--------------------------------------------final-----
#!/usr/bin/python3


from mininet.net import Mininet
from mininet.node import OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info

import time
import os



CAPTURE_PATH="/home/vboxuser/captures"



def start_capture(switch,filename):

    switch.cmd(
        f"""
        tcpdump -i any -w {CAPTURE_PATH}/{filename} &
        """
    )



def stop_capture():

    os.system(
        "killall tcpdump"
    )



def HIoT_Network():


    info("\n*** Creating HIoT Network ***\n")



    net = Mininet(

        switch=OVSSwitch,

        controller=None

    )



    s1 = net.addSwitch(

        's1',

        failMode='standalone'

    )



    # ===============================
    # HIoT DEVICES
    # ===============================


    ecg = net.addHost(

        'ecg',

        ip='10.0.0.1'

    )


    monitor = net.addHost(

        'monitor',

        ip='10.0.0.2'

    )


    pump = net.addHost(

        'pump',

        ip='10.0.0.3'

    )


    wearable = net.addHost(

        'wearable',

        ip='10.0.0.4'

    )



    server = net.addHost(

        'server',

        ip='10.0.0.10'

    )



    attacker1 = net.addHost(

        'attacker1',

        ip='10.0.0.66'

    )


    attacker2 = net.addHost(

        'attacker2',

        ip='10.0.0.67'

    )


    attacker3 = net.addHost(

        'attacker3',

        ip='10.0.0.68'

    )


    attacker4 = net.addHost(

        'attacker4',

        ip='10.0.0.69'

    )




    hosts=[

        ecg,
        monitor,
        pump,
        wearable,
        server,

        attacker1,
        attacker2,
        attacker3,
        attacker4

    ]



    for h in hosts:

        net.addLink(

            h,

            s1

        )




    net.start()



    info("\n*** Network Started ***\n")



    server.cmd(

        f"mkdir -p {CAPTURE_PATH}"

    )



    time.sleep(3)



    # ==================================
    # SERVER SERVICES
    # ==================================


    server.cmd(

        "python3 -m http.server 80 &"

    )



    server.cmd(

    """

    while true

    do

    nc -lk 4444

    done

    &

    """

    )



    time.sleep(5)



    # ==================================
    # NORMAL TRAFFIC
    # ==================================


    info("\n*** NORMAL TRAFFIC ***\n")



    start_capture(

        s1,

        "normal.pcap"

    )



    ecg.cmd(

    """

    for i in $(seq 1 500)

    do

    curl -s \
    -X POST \
    -d "device=ECG&heartrate=80&spo2=98" \
    http://10.0.0.10


    sleep 1

    done &

    """

    )




    monitor.cmd(

    """

    for i in $(seq 1 500)

    do

    curl -s \
    -X POST \
    -d "temperature=36.5&bp=120/80" \
    http://10.0.0.10


    sleep 2

    done &

    """

    )




    pump.cmd(

    """

    for i in $(seq 1 500)

    do

    curl -s \
    -X POST \
    -d "infusion=5ml" \
    http://10.0.0.10


    sleep 3

    done &

    """

    )



    time.sleep(120)



    stop_capture()



    # ==================================
    # SCANNING
    # ==================================


    info("\n*** SCANNING ATTACK ***\n")



    start_capture(

        s1,

        "scanning.pcap"

    )



    attacker1.cmd(

    """

    nmap -sS -sV -p 1-5000 10.0.0.10

    """

    )


    time.sleep(60)


    stop_capture()




    # ==================================
    # DOS
    # ==================================


    info("\n*** DOS ATTACK ***\n")



    start_capture(

        s1,

        "dos.pcap"

    )



    attacker1.cmd(

    """

    hping3 \
    -S \
    -p 80 \
    --flood \
    10.0.0.10

    """

    )


    time.sleep(60)


    stop_capture()




    # ==================================
    # DDOS
    # ==================================


    info("\n*** DDOS ATTACK ***\n")



    start_capture(

        s1,

        "ddos.pcap"

    )



    for attacker in [

        attacker1,

        attacker2,

        attacker3,

        attacker4

    ]:


        attacker.cmd(

        """

        hping3 \
        -S \
        -p 80 \
        --flood \
        10.0.0.10 &

        """

        )



    time.sleep(60)


    stop_capture()




    # ==================================
    # BACKDOOR
    # ==================================


    info("\n*** BACKDOOR ATTACK ***\n")



    start_capture(

        s1,

        "backdoor.pcap"

    )



    attacker1.cmd(

    """

    for i in $(seq 1 500)

    do

    echo "root login access" | nc 10.0.0.10 4444

    done

    """

    )


    time.sleep(60)



    stop_capture()



    info(

    """

=====================================

PCAP CREATED:

normal.pcap
scanning.pcap
dos.pcap
ddos.pcap
backdoor.pcap


Location:

/home/vboxuser/captures/

=====================================

"""

    )


    CLI(net)


    net.stop()





if __name__=="__main__":

    setLogLevel('info')

    HIoT_Network()

# #--------------------------------------------------

# from mininet.net import Mininet
# from mininet.node import OVSSwitch
# from mininet.link import TCLink
# from mininet.log import setLogLevel
# import time


# def run():

#     net = Mininet(
#         switch=OVSSwitch,
#         controller=None,
#         link=TCLink
#     )


#     print("Creating Switch...")

#     s1 = net.addSwitch(
#         "s1",
#         failMode="standalone"
#     )


#     print("Creating Healthcare IoT Devices...")


#     # Healthcare IoT Devices

#     h1 = net.addHost(
#         "h1",
#         ip="10.0.0.1/24"
#     )

#     h2 = net.addHost(
#         "h2",
#         ip="10.0.0.2/24"
#     )

#     h3 = net.addHost(
#         "h3",
#         ip="10.0.0.3/24"
#     )


#     # Gateway

#     h4 = net.addHost(
#         "h4",
#         ip="10.0.0.4/24"
#     )


#     # Healthcare Server

#     h5 = net.addHost(
#         "h5",
#         ip="10.0.0.10/24"
#     )


#     # Doctor PC

#     h6 = net.addHost(
#         "h6",
#         ip="10.0.0.20/24"
#     )


#     # Attackers

#     h7 = net.addHost(
#         "h7",
#         ip="10.0.0.101/24"
#     )

#     h8 = net.addHost(
#         "h8",
#         ip="10.0.0.102/24"
#     )

#     h9 = net.addHost(
#         "h9",
#         ip="10.0.0.103/24"
#     )


#     hosts = [
#         h1, h2, h3,
#         h4, h5, h6,
#         h7, h8, h9
#     ]


#     print("Creating Links...")


#     for h in hosts:

#         net.addLink(
#             h,
#             s1,
#             bw=10,
#             delay="2ms"
#         )


#     print("Starting Network...")

#     net.start()


#     print("\nNetwork Started\n")


#     print("Host Addresses")

#     for h in hosts:

#         print(
#             h.name,
#             h.IP()
#         )


#     ##################################################
#     # PACKET CAPTURE
#     ##################################################

#     print("\nStarting Packet Capture...")


#     h5.cmd(
#         "tcpdump -i h5-eth0 "
#         "-w /home/vboxuser/captures/hiot_capture.pcap "
#         ">/dev/null 2>&1 &"
#     )


#     ##################################################
#     # HEALTHCARE SERVER
#     ##################################################

#     print("Starting Healthcare Server")


#     h5.cmd(
#         "python3 -m http.server 8080 "
#         ">/dev/null 2>&1 &"
#     )


#     time.sleep(5)



#     ##################################################
#     # NORMAL TRAFFIC
#     ##################################################

#     print("\nGenerating Normal Healthcare Traffic")


#     for i in range(50):

#         h1.cmd(
#             "wget -q -O- http://10.0.0.10:8080"
#         )


#         h2.cmd(
#             "wget -q -O- http://10.0.0.10:8080"
#         )


#         h3.cmd(
#             "wget -q -O- http://10.0.0.10:8080"
#         )


#         h1.cmd(
#             "ping -c 2 10.0.0.10"
#         )


#         h2.cmd(
#             "ping -c 2 10.0.0.10"
#         )


#         time.sleep(1)



#     ##################################################
#     # PORT SCANNING
#     ##################################################

#     print("\nGenerating Port Scan")


#     h8.cmd(
#         "nmap -sS 10.0.0.10 "
#         ">/tmp/nmap_scan.txt"
#     )



#     ##################################################
#     # DOS ATTACK
#     ##################################################

#     print("\nGenerating DoS Attack")


#     h7.cmd(
#         "timeout 30 "
#         "hping3 -S --flood "
#         "-p 8080 "
#         "10.0.0.10 "
#         ">/dev/null 2>&1 &"
#     )


#     time.sleep(35)



#     ##################################################
#     # DDOS ATTACK
#     ##################################################

#     print("\nGenerating DDoS Attack")


#     h7.cmd(
#         "timeout 30 hping3 -S --flood "
#         "-p 8080 10.0.0.10 "
#         ">/dev/null 2>&1 &"
#     )


#     h8.cmd(
#         "timeout 30 hping3 -S --flood "
#         "-p 8080 10.0.0.10 "
#         ">/dev/null 2>&1 &"
#     )


#     h9.cmd(
#         "timeout 30 hping3 -S --flood "
#         "-p 8080 10.0.0.10 "
#         ">/dev/null 2>&1 &"
#     )


#     time.sleep(35)



#     ##################################################
#     # EXTRA NORMAL TRAFFIC
#     ##################################################

#     print("\nGenerating Additional Normal Traffic")


#     for i in range(30):

#         h1.cmd(
#             "wget -q -O- http://10.0.0.10:8080"
#         )


#         h2.cmd(
#             "wget -q -O- http://10.0.0.10:8080"
#         )


#         h6.cmd(
#             "ping -c 1 10.0.0.10"
#         )


#         time.sleep(1)



#     ##################################################
#     # STOP CAPTURE
#     ##################################################

#     print("\nStopping Packet Capture")


#     h5.cmd(
#         "pkill tcpdump"
#     )


#     time.sleep(5)



#     print("\n===================================")

#     print("HIoT PCAP Generated Successfully")

#     print(
#         "/home/vboxuser/captures/hiot_capture.pcap"
#     )

#     print("===================================")



#     net.stop()



# if __name__ == "__main__":

#     setLogLevel("info")

#     run()
