# import pandas as pd
# import os


# # =========================================================
# # PATH CONFIGURATION
# # =========================================================

# BASE_PATH = "/home/vboxuser/captures"

# CONN_LOG = os.path.join(BASE_PATH, "conn.log")
# HTTP_LOG = os.path.join(BASE_PATH, "http.log")

# OUTPUT_FILE = os.path.join(
#     BASE_PATH,
#     "mininet_dataset.csv"
# )



# # =========================================================
# # ZEEK LOG READER
# # =========================================================

# def read_zeek_log(filename):

#     if not os.path.exists(filename):
#         return pd.DataFrame()


#     fields = None
#     data = []


#     with open(filename, "r") as file:

#         for line in file:

#             line=line.rstrip("\n")


#             if line.startswith("#fields"):

#                 fields=line.split("\t")[1:]
#                 continue


#             if line.startswith("#"):

#                 continue


#             if fields:

#                 values=line.split("\t")

#                 if len(values)==len(fields):

#                     data.append(values)



#     if fields is None:

#         return pd.DataFrame()



#     return pd.DataFrame(
#         data,
#         columns=fields
#     )



# # =========================================================
# # LOAD CONNECTION LOG
# # =========================================================

# print("Reading conn.log")


# conn=read_zeek_log(CONN_LOG)


# if conn.empty:

#     raise Exception(
#         "conn.log contains no flow data"
#     )


# print("Flows detected:", len(conn))



# # =========================================================
# # RENAME ZEEK FEATURES
# # =========================================================

# rename_conn={


# "id.orig_h":"src_ip",
# "id.orig_p":"src_port",

# "id.resp_h":"dst_ip",
# "id.resp_p":"dst_port",


# "orig_bytes":"src_bytes",
# "resp_bytes":"dst_bytes",


# "orig_pkts":"src_pkts",
# "resp_pkts":"dst_pkts",


# "orig_ip_bytes":"src_ip_bytes",
# "resp_ip_bytes":"dst_ip_bytes"


# }



# conn.rename(
#     columns=rename_conn,
#     inplace=True
# )



# # =========================================================
# # CONVERT NUMERIC FEATURES
# # =========================================================


# numeric_columns=[

# "src_port",
# "dst_port",

# "duration",

# "src_bytes",
# "dst_bytes",

# "src_pkts",
# "dst_pkts",

# "src_ip_bytes",
# "dst_ip_bytes"

# ]


# for col in numeric_columns:

#     if col in conn.columns:

#         conn[col]=pd.to_numeric(
#             conn[col],
#             errors="coerce"
#         )



# # Replace Zeek missing values

# conn.replace(
#     "-",
#     "unknown",
#     inplace=True
# )



# # =========================================================
# # HTTP LOG MERGE
# # =========================================================


# http=read_zeek_log(HTTP_LOG)



# if not http.empty:


#     print("Reading http.log")


#     http.rename(
#         columns=rename_conn,
#         inplace=True
#     )


#     http.rename(
#         columns={

#             "method":"http_method",

#             "uri":"http_uri",

#             "version":"http_version",

#             "request_body_len":
#             "http_request_body_len",

#             "response_body_len":
#             "http_response_body_len",

#             "status_code":
#             "http_status_code",

#             "user_agent":
#             "http_user_agent",

#             "orig_mime_types":
#             "http_orig_mime_types",

#             "resp_mime_types":
#             "http_resp_mime_types"


#         },
#         inplace=True
#     )


#     http_columns=[

#         "src_ip",
#         "dst_ip",

#         "method",
#         "http_method",

#         "http_uri",
#         "http_version",

#         "http_request_body_len",

#         "http_response_body_len",

#         "http_status_code",

#         "http_user_agent",

#         "http_orig_mime_types",

#         "http_resp_mime_types"

#     ]


#     http_columns=[

#         c for c in http_columns

#         if c in http.columns

#     ]


#     if (
#         "src_ip" in http.columns
#         and
#         "dst_ip" in http.columns
#     ):


#         # IMPORTANT FIX
#         # Remove duplicate HTTP records

#         http=http.drop_duplicates(
#             subset=[
#                 "src_ip",
#                 "dst_ip"
#             ]
#         )


#         conn=conn.merge(

#             http[http_columns],

#             on=[
#                 "src_ip",
#                 "dst_ip"
#             ],

#             how="left"

#         )



# # =========================================================
# # ADD MISSING IDS FEATURES
# # =========================================================


# default_values={


# "service":"unknown",

# "conn_state":"unknown",

# "missed_bytes":0,


# "dns_query":"unknown",

# "dns_qclass":0,

# "dns_qtype":0,

# "dns_rcode":0,

# "dns_AA":"unknown",

# "dns_RD":"unknown",

# "dns_RA":"unknown",

# "dns_rejected":"unknown",



# "ssl_version":"unknown",

# "ssl_cipher":"unknown",

# "ssl_resumed":"unknown",

# "ssl_established":"unknown",

# "ssl_subject":"unknown",

# "ssl_issuer":"unknown",



# "http_trans_depth":0,

# "http_method":"unknown",

# "http_uri":"unknown",

# "http_version":"unknown",

# "http_request_body_len":0,

# "http_response_body_len":0,

# "http_status_code":0,

# "http_user_agent":"unknown",

# "http_orig_mime_types":"unknown",

# "http_resp_mime_types":"unknown",



# "weird_name":"unknown",

# "weird_addl":"unknown",

# "weird_notice":"unknown"


# }



# for col,val in default_values.items():

#     if col not in conn.columns:

#         conn[col]=val



# # =========================================================
# # LABEL
# # =========================================================

# conn["label"]=0

# conn["type"]="normal"



# # =========================================================
# # FINAL COLUMNS
# # =========================================================


# columns=[


# "src_ip",
# "src_port",

# "dst_ip",
# "dst_port",

# "proto",

# "service",

# "duration",

# "src_bytes",
# "dst_bytes",

# "conn_state",

# "missed_bytes",

# "src_pkts",
# "src_ip_bytes",

# "dst_pkts",
# "dst_ip_bytes",


# "dns_query",

# "dns_qclass",

# "dns_qtype",

# "dns_rcode",

# "dns_AA",

# "dns_RD",

# "dns_RA",

# "dns_rejected",


# "ssl_version",

# "ssl_cipher",

# "ssl_resumed",

# "ssl_established",

# "ssl_subject",

# "ssl_issuer",


# "http_trans_depth",

# "http_method",

# "http_uri",

# "http_version",

# "http_request_body_len",

# "http_response_body_len",

# "http_status_code",

# "http_user_agent",

# "http_orig_mime_types",

# "http_resp_mime_types",


# "weird_name",

# "weird_addl",

# "weird_notice",


# "label",

# "type"

# ]



# for col in columns:

#     if col not in conn.columns:

#         conn[col]="unknown"



# dataset=conn[columns]



# # remove duplicate flows

# dataset.drop_duplicates(
#     inplace=True
# )



# dataset.fillna(
#     "unknown",
#     inplace=True
# )



# # =========================================================
# # SAVE DATASET
# # =========================================================


# dataset.to_csv(

#     OUTPUT_FILE,

#     index=False

# )



# print("\n==============================")
# print("Zeek Dataset Created")
# print("==============================")

# print(
# "Saved:",
# OUTPUT_FILE
# )

# print(
# "Shape:",
# dataset.shape
# )

# print(
# dataset.head()
# )
#----------------------------------------------final
# import pandas as pd
# import json
# import os


# # Location of Zeek logs
# log_path = "/home/vboxuser/captures/zeek_logs"


# # Files and labels
# files = {
#     "normal_conn.log": "normal",
#     "scanning_conn.log": "scanning",
#     "dos_conn.log": "dos",
#     "backdoor_conn.log": "backdoor"
# }


# all_data = []


# for file, label in files.items():

#     print("\nProcessing:", file)


#     file_path = os.path.join(
#         log_path,
#         file
#     )


#     rows = []


#     # Read Zeek JSON log
#     with open(file_path, "r") as f:

#         for line in f:

#             line = line.strip()

#             if line:

#                 rows.append(
#                     json.loads(line)
#                 )


#     df = pd.DataFrame(rows)


#     print("Samples:", len(df))


#     # Add attack label

#     df["type"] = label


#     all_data.append(df)



# # Merge all traffic

# mininet_dataset = pd.concat(
#     all_data,
#     ignore_index=True
# )



# print("\n======================")
# print("Dataset Shape")
# print("======================")

# print(
#     mininet_dataset.shape
# )



# print("\n======================")
# print("Class Distribution")
# print("======================")

# print(
#     mininet_dataset["type"].value_counts()
# )



# # Save CSV

# output_file = "/home/vboxuser/captures/mininet_hiot_dataset.csv"


# mininet_dataset.to_csv(
#     output_file,
#     index=False
# )


# print("\nCSV Created:")
# print(output_file)

#-----------------------------------------------
import pandas as pd
import os


columns = [

    "ts",
    "uid",
    "id.orig_h",
    "id.orig_p",
    "id.resp_h",
    "id.resp_p",
    "proto",
    "service",
    "duration",
    "orig_bytes",
    "resp_bytes",
    "conn_state",
    "local_orig",
    "local_resp",
    "missed_bytes",
    "history",
    "orig_pkts",
    "orig_ip_bytes",
    "resp_pkts",
    "resp_ip_bytes",
    "tunnel_parents",
    "ip_proto"

]


files = {

"/home/vboxuser/captures/zeek_logs/normal/conn.csv":"normal",

"/home/vboxuser/captures/zeek_logs/scanning/conn.csv":"scanning",

"/home/vboxuser/captures/zeek_logs/dos/conn.csv":"dos",

"/home/vboxuser/captures/zeek_logs/ddos/conn.csv":"ddos",

"/home/vboxuser/captures/zeek_logs/password/conn.csv":"password",

"/home/vboxuser/captures/zeek_logs/web/conn.csv":"xss",

"/home/vboxuser/captures/zeek_logs/backdoor/conn.csv":"backdoor"

}



datasets=[]



for file,label in files.items():


    print("Loading:",file)


    if os.path.exists(file):


        df=pd.read_csv(

            file,

            header=None,

            names=columns,

            sep=",",

            engine="python"

        )


        print(df.shape)


        df["type"]=label


        datasets.append(df)



    else:

        print("Missing:",file)




final=pd.concat(

    datasets,

    ignore_index=True

)



print("\nFinal shape:")
print(final.shape)



print("\nClasses:")
print(final["type"].value_counts())



final.to_csv(

"/media/sf_HIoT_IDS_Project/data/mininet_zeek_dataset.csv",

index=False

)


print("Saved")